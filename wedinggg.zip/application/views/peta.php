  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <div id="map_peta" style="height: 600px;">
                
    </div>
  </div>
  <!-- /.content-wrapper -->